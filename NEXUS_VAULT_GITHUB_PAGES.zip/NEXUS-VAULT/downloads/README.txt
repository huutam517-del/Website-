NEXUS VAULT — DOWNLOADS

Thư mục này dành cho các tệp tài nguyên THẬT mà bạn có quyền phân phối.

Hiện chưa có tệp tải nào được cung cấp. Không có file giả hoặc file rỗng trong bản phát hành này.

Cách xuất bản:
1. Thêm tệp thật vào thư mục downloads/ (ví dụ: ten-goi.zip).
2. Mở assets/js/resources.js.
3. Với mục tương ứng, đặt:
   status: "published"
   file: "../downloads/ten-goi.zip"   (nếu trang chi tiết nằm trong pages/)
   hoặc đường dẫn tương đối phù hợp với vị trí trang.
4. Điền size, version, updated, description và hướng dẫn chính xác.
5. Kiểm tra URL khi triển khai dưới GitHub Pages repository con.

Chỉ đăng tải nội dung bạn sở hữu hoặc có quyền phân phối.
