# NEXUS VAULT — GitHub Pages

Website tĩnh phân phối tài nguyên game theo phong cách Anime Cyberpunk / Premium Gaming Vault.

## Chạy thử
- Mở `index.html` trực tiếp trong trình duyệt.
- Hoặc triển khai thư mục gốc lên GitHub Pages.
- Không cần Node.js, build step, database hay backend cho các tính năng tĩnh.

## Triển khai GitHub Pages
1. Tạo repository GitHub mới.
2. Giải nén ZIP, sau đó upload toàn bộ **nội dung** thư mục `NEXUS-VAULT/` lên repository (để `index.html` nằm ở root).
3. Vào **Settings → Pages**.
4. Ở **Build and deployment**, chọn **Deploy from a branch**.
5. Chọn branch `main`, folder `/ (root)`, rồi Save.
6. Đợi GitHub Pages xuất bản và mở URL được cung cấp, thường có dạng `https://username.github.io/repository/`.

## Thêm tài nguyên có thể tải thật
1. Đặt tệp thực tế vào `downloads/` (ZIP, RAR, DAT, INI, TXT hoặc định dạng phù hợp).
2. Mở `assets/js/resources.js`, sửa mục tương ứng:
   - `status: "published"`
   - `file: "../downloads/ten-file.zip"` đối với trang chi tiết trong `pages/`.
   - Điền `size`, `version`, `updated`, mô tả và hướng dẫn đúng với tệp.
3. Với đường dẫn trong card ở trang chủ/catalog, nên dùng đường dẫn tương đối từ root như `downloads/ten-file.zip`; nếu dùng chung một giá trị cho cả trang chi tiết, hãy dùng URL tương đối theo vị trí trang hoặc đổi code để chuẩn hóa URL. Không bật published khi chưa có tệp thật.
4. Commit và push lại repository. GitHub Pages sẽ phục vụ tệp tĩnh.

**Lưu ý:** GitHub Pages không có backend. Các file tải phải nằm trong repository (có giới hạn dung lượng của GitHub) hoặc được lưu ở dịch vụ lưu trữ bên ngoài. Không đưa tệp lớn/nhạy cảm vào Git.

## Những gì hoạt động độc lập
- Trang chủ, danh mục, tìm kiếm, lọc, sắp xếp, trang chi tiết.
- Yêu thích qua LocalStorage (trên cùng trình duyệt/thiết bị).
- Responsive mobile/tablet/desktop.
- Tải xuống tệp tĩnh khi quản trị viên cấu hình đúng đường dẫn và trạng thái phát hành.
- Biểu mẫu liên hệ tạo email bằng `mailto:` (phụ thuộc ứng dụng email trên thiết bị).

## Những gì cần backend hoặc dịch vụ ngoài
- Đăng nhập, tài khoản, phân quyền quản trị.
- Cơ sở dữ liệu và đồng bộ yêu thích nhiều thiết bị.
- Upload tài nguyên công khai, kiểm duyệt và quản lý phiên bản từ giao diện.
- Thống kê lượt tải đáng tin cậy, analytics tập trung.
- Form gửi dữ liệu trực tiếp tới máy chủ.

Có thể tích hợp Firebase, Supabase, Formspree hoặc API riêng nếu cần các chức năng này. Cần cấu hình khóa/API và chính sách bảo mật riêng; không nhúng secret key vào mã nguồn công khai.

## Cấu trúc
```text
NEXUS-VAULT/
├── index.html
├── README.md
├── .nojekyll
├── assets/
│   ├── css/ (style.css, responsive.css)
│   ├── js/ (app.js, resources.js, components.js)
│   └── img/ (logo, hero, backgrounds, thumbnails, icons)
├── downloads/
└── pages/
    ├── catalog.html
    ├── favorites.html
    ├── resource.html
    ├── guide.html
    └── contact.html
```

## Ghi chú về nội dung
Các mục catalog trong bản ZIP là bản ghi danh mục minh họa và đang ở trạng thái **Chưa phát hành**. Không có file tải giả. Hero artwork và vector thumbnail là tài nguyên hình ảnh được tạo riêng cho dự án.
